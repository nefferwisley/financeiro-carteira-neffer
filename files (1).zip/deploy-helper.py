#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
🚀 CARTEIRA — Deploy Helper
Simplifica deployment no Vercel em 2 minutos
"""

import os
import sys
import subprocess
import platform

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def print_header():
    print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║        🚀 CARTEIRA — Deploy Helper (Vercel)                   ║
║                                                                ║
║       2 MINUTOS ATÉ SEU SITE ESTAR LIVE NA INTERNET           ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
    """)

def print_step(n, title):
    print(f"\n{'='*60}")
    print(f"  PASSO {n} — {title}")
    print(f"{'='*60}\n")

def check_git():
    try:
        subprocess.run(['git', '--version'], capture_output=True, check=True)
        print("✅ Git instalado e pronto")
        return True
    except:
        print("❌ Git NÃO instalado!")
        print("\n📥 Download em: https://git-scm.com/")
        print("\nDepois que instalar, roda este script de novo.")
        input("\n(Pressiona ENTER pra fechar)")
        return False

def check_github_auth():
    try:
        result = subprocess.run(['git', 'config', 'user.email'], 
                              capture_output=True, text=True)
        email = result.stdout.strip()
        if email and '@' in email:
            print(f"✅ Git configurado: {email}")
            return True
    except:
        pass
    print("⚠️  Git não está configurado ainda")
    return False

def setup_git():
    print_step(1, "Configurar Git (primeira vez)")
    
    print("Você precisa se identificar no Git (só primeira vez):\n")
    
    name = input("👤 Seu nome (ex: Neffer): ").strip()
    if not name:
        name = "Neffer"
    
    email = input("📧 Seu email (ex: seu@email.com): ").strip()
    if not email:
        email = "neffer@carteira.dev"
    
    subprocess.run(['git', 'config', '--global', 'user.name', name])
    subprocess.run(['git', 'config', '--global', 'user.email', email])
    
    print(f"\n✅ Git configurado como: {name} ({email})")

def show_github_setup():
    print_step(2, "Criar Repo no GitHub")
    
    print("""
VOCÊ PRECISA FAZER ISSO NO NAVEGADOR:

1️⃣  Vai em: https://github.com/new

2️⃣  Preenche:
    • Repository name: financeiro-carteira
    • Descrição: Controle financeiro com OCR
    • Public: ✓ (deixa marcado)
    • Initialize repository: deixa desmarcado

3️⃣  Clica "Create repository"

⏱️  Deve levar ~30 segundos

    """)
    
    input("Quando terminar, pressiona ENTER...")

def get_github_url():
    print("\n📋 Agora você precisa da URL do seu repo GitHub.\n")
    print("Vai em: https://github.com/SEU-USERNAME/financeiro-carteira")
    print("Clica no botão verde '<> Code'")
    print("Copia a URL (tipo: https://github.com/SEU-USERNAME/financeiro-carteira.git)\n")
    
    url = input("Cola a URL aqui: ").strip()
    
    if not url.startswith('https://github.com/'):
        print("\n❌ URL inválida!")
        return None
    
    return url

def push_to_github(github_url):
    print_step(3, "Fazer Push (Enviar pra GitHub)")
    
    print("Rodando comandos git...\n")
    
    try:
        subprocess.run(['git', 'remote', 'add', 'origin', github_url], check=True)
        print("✅ Remote adicionado")
        
        subprocess.run(['git', 'branch', '-M', 'main'], check=True)
        print("✅ Branch renomeada pra 'main'")
        
        subprocess.run(['git', 'push', '-u', 'origin', 'main'], check=True)
        print("✅ Enviado pro GitHub!")
        
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erro durante push: {e}")
        print("\nMas pode ser erro de autenticação. Verifica:")
        print("1. Copiar a URL correta do GitHub")
        print("2. Ter credenciais configuradas (GitHub CLI ou PAT)")
        return False

def show_vercel_setup():
    print_step(4, "Fazer Deploy no Vercel")
    
    print("""
VOCÊ PRECISA FAZER ISSO NO NAVEGADOR:

1️⃣  Vai em: https://vercel.com

2️⃣  Loga (com GitHub é mais fácil)

3️⃣  Clica "Add New" → "Project"

4️⃣  Seleciona "financeiro-carteira"

5️⃣  Clica "Import"

6️⃣  Vercel detecta tudo automaticamente

7️⃣  Clica "Deploy" (botão grande lá embaixo)

⏱️  Espera 1-2 minutos...

8️⃣  PRONTO! Clica no link que aparece:
    https://financeiro-carteira.vercel.app

    """)
    
    input("Quando terminar, pressiona ENTER...")

def show_success():
    clear()
    print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║                    ✅ SITE LIVE! 🎉                           ║
║                                                                ║
║            Seu controle financeiro está online!                ║
║                                                                ║
║         https://financeiro-carteira.vercel.app                ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝

🎯 PRÓXIMAS AÇÕES:

1. Compartilha a URL com quem quiser
2. Pra atualizar o código depois:
   - Edita o arquivo
   - git add .
   - git commit -m "descrição"
   - git push
   - Vercel faz deploy automático!

3. Quer domínio custom? Configure no Vercel depois

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📚 Documentação completa em:
   • README.md
   • COWORK_CONTEXT.md
   • STATUS_TECNICO.md

🚀 Boa sorte!
    """)

def main():
    clear()
    print_header()
    
    # Passo 1: Verificar Git
    if not check_git():
        return
    
    # Passo 2: Configurar Git se necessário
    if not check_github_auth():
        setup_git()
    
    # Passo 3: Criar repo GitHub
    show_github_setup()
    
    # Passo 4: Pegar URL do GitHub
    github_url = get_github_url()
    if not github_url:
        print("\n❌ Deploy cancelado")
        return
    
    # Passo 5: Fazer push
    if not push_to_github(github_url):
        print("\n⚠️  Push pode ter falhado, mas continua...")
        input("Pressiona ENTER pra continuar...")
    
    # Passo 6: Deploy no Vercel
    show_vercel_setup()
    
    # Sucesso!
    show_success()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n❌ Deploy cancelado pelo usuário")
        sys.exit(0)
    except Exception as e:
        print(f"\n\n❌ Erro: {e}")
        sys.exit(1)
