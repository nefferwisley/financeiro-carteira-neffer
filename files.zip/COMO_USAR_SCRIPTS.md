# 🤖 Como Usar os Scripts de Deploy

Você tem **3 opções** — escolha a que mais gosta:

---

## 🐍 OPÇÃO 1: Python (⭐ RECOMENDADO)

**Funciona em:** Windows, Mac, Linux  
**Vantagem:** Mais inteligente, guia passo-a-passo, cores bonitas  
**Requisito:** Python 3.6+ (já vem instalado em Mac/Linux)

### Passo 1: Abrir terminal na pasta
```bash
cd /caminho/para/financeiro-vercel
```

### Passo 2: Rodar o script
```bash
python3 deploy.py
```

ou (Windows):
```bash
python deploy.py
```

### Passo 3: Seguir as instruções
- Script pede a URL do seu repo GitHub
- Roda tudo automático
- Avisa quando termina

---

## 🐚 OPÇÃO 2: Bash Script (Mac/Linux)

**Funciona em:** Mac, Linux  
**Vantagem:** Super rápido, sem dependências  
**Requisito:** Bash (padrão em Mac/Linux)

### Passo 1: Dar permissão de execução
```bash
chmod +x deploy.sh
```

### Passo 2: Rodar
```bash
./deploy.sh
```

### Passo 3: Seguir as instruções
- Script pede URL do GitHub
- Automatiza tudo
- Avisa quando termina

---

## 🪟 OPÇÃO 3: Batch Script (Windows)

**Funciona em:** Windows (PowerShell, CMD)  
**Vantagem:** Nativo do Windows, sem instalações  
**Requisito:** Nenhum (Windows puro)

### Passo 1: Abrir pasta no Explorer
- Vai em `financeiro-vercel`
- Clica direito → "Abrir PowerShell aqui"

### Passo 2: Rodar
```bash
.\deploy.bat
```

ou:
```bash
deploy.bat
```

### Passo 3: Seguir as instruções
- Script pede URL do GitHub
- Automatiza tudo
- Avisa quando termina

---

## 📋 O Que Cada Script Faz

Todos fazem a **FASE 2 completa**:

```bash
1️⃣  git init           ← Inicializa repositório Git
2️⃣  git add .          ← Adiciona todos os arquivos
3️⃣  git commit         ← Salva um checkpoint
4️⃣  git branch -M main ← Renomeia para main
5️⃣  git remote add     ← Conecta ao GitHub
6️⃣  git push           ← Envia pro GitHub
```

---

## 🎯 Antes de Rodar Qualquer Script

**Checklist:**

- ✅ Você criou o repo no GitHub?
  - Vai em https://github.com/new
  - Nome: `financeiro-carteira`
  - Public: ✓
  - Clica "Create"

- ✅ Você tem Git instalado?
  - Terminal: `git --version`
  - Se não: https://git-scm.com/

- ✅ Você tá na pasta certa?
  - Terminal: `ls` (Mac/Linux) ou `dir` (Windows)
  - Deve aparecer `index.html`, `vercel.json`, etc

---

## 🚀 Fluxo Completo

```
1. Criar repo no GitHub (https://github.com/new)
   ↓
2. Rodar script (python3 deploy.py)
   ↓
3. Script pede URL do GitHub
   ↓
4. Script roda 6 comandos Git automaticamente
   ↓
5. Você vê "✅ GIT PUSH SUCESSO!"
   ↓
6. Ir pra Vercel (https://vercel.com)
   ↓
7. Import repo → Deploy
   ↓
8. 🎉 Site Live!
```

---

## ⚠️ Erros Comuns

### "command not found: git"
**Problema:** Git não instalado  
**Solução:** https://git-scm.com/

### "fatal: not a git repository"
**Problema:** Você não tá na pasta certa  
**Solução:** 
```bash
cd financeiro-vercel
ls  # Mac/Linux
dir # Windows
```

### "Error in git push"
**Problema:** URL do GitHub errada ou credenciais inválidas  
**Solução:** Verifica a URL, tenta de novo

### "python3: command not found" (Mac/Linux)
**Problema:** Python não instalado  
**Solução:** `brew install python3` (Mac) ou `apt install python3` (Linux)

### "python: command not found" (Windows)
**Problema:** Python não tá no PATH  
**Solução:** Baixa em https://www.python.org/

---

## 💡 Dicas

- **Python** é a melhor opção se você quer algo "enterprise"
- **Bash** é a melhor se você é Linux/Mac power user
- **Batch** é a melhor se é puro Windows e quer coisa simples

---

## 📞 Se algo der errado

1. Roda o script novamente
2. Se continuar erro, tenta manualmente:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/SEU-USER/financeiro-carteira.git
   git push -u origin main
   ```
3. Se ainda tiver erro, lê **COWORK_CONTEXT.md** na seção "Erros Comuns"

---

## ✅ Depois que terminar

1. ✅ Script diz "GIT PUSH SUCESSO"
2. ✅ Seu código tá no GitHub
3. ✅ Próximo passo é Vercel (ele mesmo guia)

**Bora rodar o script! 🚀**
