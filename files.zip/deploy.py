#!/usr/bin/env python3
"""
🚀 CARTEIRA — Deploy Script (Python)
Automático em Windows, Mac e Linux
"""

import subprocess
import sys
import os
import platform
import webbrowser
from pathlib import Path

class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header():
    print("\n" + "╔" + "═"*62 + "╗")
    print("║" + " "*62 + "║")
    print("║  🚀 CARTEIRA — Deploy Automático".ljust(62) + "║")
    print("║" + " "*62 + "║")
    print("╚" + "═"*62 + "╝\n")

def print_step(step_num, title):
    print(f"\n{Colors.YELLOW}📌 Passo {step_num}: {title}{Colors.RESET}")

def run_command(cmd, description=""):
    """Roda comando e checa se funcionou"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"{Colors.GREEN}✅ {description} OK{Colors.RESET}")
            return True
        else:
            print(f"{Colors.RED}❌ Erro: {result.stderr}{Colors.RESET}")
            return False
    except Exception as e:
        print(f"{Colors.RED}❌ Erro ao executar: {e}{Colors.RESET}")
        return False

def check_git():
    """Verifica se Git está instalado"""
    try:
        subprocess.run("git --version", shell=True, capture_output=True, check=True)
        return True
    except:
        return False

def get_repo_url():
    """Pede URL do repo do usuário"""
    print("\n" + "="*64)
    print("📍 Configure seu GitHub Repository")
    print("="*64)
    print("\n1. Vai em: https://github.com/new")
    print("2. Nome do repo: financeiro-carteira")
    print("3. Deixa PÚBLICO")
    print("4. Clica 'Create repository'")
    print("\n5. Clica no botão verde '<> Code'")
    print("6. COPIA a URL (HTTPS)")
    print("\nExemplo: https://github.com/seu-usuario/financeiro-carteira.git")
    print("\n" + "="*64 + "\n")
    
    url = input(f"{Colors.BOLD}Cole a URL do seu repo aqui: {Colors.RESET}").strip()
    
    if not url:
        print(f"{Colors.RED}❌ URL não pode estar vazia!{Colors.RESET}")
        return None
    
    if "github.com" not in url:
        print(f"{Colors.RED}❌ URL parece inválida (não contém github.com){Colors.RESET}")
        return None
    
    return url

def main():
    # Header
    print_header()
    
    # Verificar Git
    print(f"{Colors.YELLOW}Verificando se Git está instalado...{Colors.RESET}")
    if not check_git():
        print(f"{Colors.RED}❌ Git não encontrado!{Colors.RESET}")
        print("\nBaixa Git em: https://git-scm.com/")
        print("Depois roda este script novamente.")
        sys.exit(1)
    print(f"{Colors.GREEN}✅ Git encontrado{Colors.RESET}")
    
    # Pedir URL
    repo_url = get_repo_url()
    if not repo_url:
        sys.exit(1)
    
    # Começar deployment
    print(f"\n{Colors.BOLD}🚀 Começando deployment...{Colors.RESET}\n")
    
    # Passo 1: git init
    print_step(1, "Inicializando Git")
    if not run_command("git init", "git init"):
        sys.exit(1)
    
    # Passo 2: git add
    print_step(2, "Adicionando arquivos")
    if not run_command("git add .", "git add ."):
        sys.exit(1)
    
    # Passo 3: git commit
    print_step(3, "Fazendo Commit")
    if not run_command('git commit -m "Initial commit: Carteira financeiro app"', "git commit"):
        sys.exit(1)
    
    # Passo 4: git branch
    print_step(4, "Renomeando branch para main")
    if not run_command("git branch -M main", "git branch -M main"):
        sys.exit(1)
    
    # Passo 5: git remote
    print_step(5, "Conectando ao GitHub")
    # Escape special chars if needed
    remote_cmd = f'git remote add origin "{repo_url}"'
    if not run_command(remote_cmd, "git remote add"):
        sys.exit(1)
    
    # Passo 6: git push
    print_step(6, "Fazendo Push (enviando pro GitHub)")
    print(f"\n{Colors.YELLOW}⏳ Isso pode levar um tempo...{Colors.RESET}")
    print(f"{Colors.YELLOW}💡 Pode pedir username/senha/token do GitHub — é normal!{Colors.RESET}\n")
    
    input(f"{Colors.BOLD}Pressione ENTER quando estiver pronto para fazer push...{Colors.RESET}")
    
    if not run_command("git push -u origin main", "git push"):
        print(f"\n{Colors.RED}❌ Erro no push!{Colors.RESET}")
        print("\nPossíveis causas:")
        print("1. URL do GitHub está errada")
        print("2. GitHub pedindo autenticação (token/2FA)")
        print("3. Repo não foi criado ainda")
        print("\nTenta manualmente no terminal:")
        print("  git push -u origin main")
        sys.exit(1)
    
    # Sucesso!
    print("\n" + "╔" + "═"*62 + "╗")
    print("║" + " "*62 + "║")
    print(f"║  {Colors.GREEN}✅ GIT PUSH SUCESSO!{Colors.RESET}".ljust(64) + "║")
    print("║" + " "*62 + "║")
    print("╚" + "═"*62 + "╝\n")
    
    print(f"{Colors.BOLD}🎯 Próximo Passo: Deploy no Vercel{Colors.RESET}\n")
    
    print("1️⃣  Vai em: https://vercel.com")
    print("2️⃣  Loga com GitHub (recomendado)")
    print("3️⃣  Clica 'Add New' → 'Project'")
    print("4️⃣  Seleciona 'financeiro-carteira'")
    print("5️⃣  Clica 'Deploy'")
    
    print(f"\n{Colors.GREEN}⏱️  Espera 1-2 minutos...{Colors.RESET}")
    print(f"{Colors.GREEN}🎉 Site fica live em: https://financeiro-carteira.vercel.app{Colors.RESET}\n")
    
    # Perguntar se quer abrir Vercel
    try:
        open_vercel = input(f"\n{Colors.BOLD}Quer abrir Vercel agora? (s/n): {Colors.RESET}").lower()
        if open_vercel == 's':
            webbrowser.open("https://vercel.com")
            print(f"\n{Colors.GREEN}✅ Abrindo Vercel no navegador...{Colors.RESET}")
    except:
        pass
    
    print(f"\n{Colors.GREEN}Tudo pronto! Boa sorte! 🚀{Colors.RESET}\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.RED}❌ Deploy cancelado pelo usuário{Colors.RESET}\n")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}❌ Erro inesperado: {e}{Colors.RESET}\n")
        sys.exit(1)
